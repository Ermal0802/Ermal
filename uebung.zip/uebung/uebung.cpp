#include <iostream>
#include <fstream>

using namespace std;

char* Eingabe() {

  //int groesseVonArr = 10 * sizeof(char);

  //int arr[10];
  
  // Malloc 
  char* arr = (char*)malloc(100 * sizeof(char));
  
  cin >> arr;
  
  return arr;
}

int main(){
  
  fstream g;
  g.open("lollkind.txt",fstream::out);
  g << "LLLLLL123412351LLOOOOOOOOOOO \nOOLLLLLLLLLLL" << endl;
 
  g.close();
 
  return 0;
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 /* char* eingegeben = Eingabe();
  
  cout << eingegeben << endl;
  
  free(eingegeben);
  
  return 0;
  
  
  char name[100];
  char* nam = name;
  
  //Eingabe
  
  cin >> nam;
  
  //Ausgabe
  cout << "Dein Name ist: ";
  
  cout << nam << endl;
  */
}