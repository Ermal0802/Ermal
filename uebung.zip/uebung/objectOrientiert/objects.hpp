#ifndef OBJECTS_HPP
#define OBJECTS_HPP

#include <iostream>
#include <string>

using namespace std;

class Person {

private:
  string Telefon;
  
public:
  string Name;
  int Alter;

  Person();
  
  virtual void print();

};

class Employee : public Person {

public:
  double Lohn;
  
  Employee();

  void print();
};

class Boss : public Employee {

public:
  int Team;
  
  Boss();
  
  void print();

};

#endif
