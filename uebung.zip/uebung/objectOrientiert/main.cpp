#include <iostream>
#include "objects.hpp"

using namespace std;



int main() {

  Person* p1 = new Person();
  Person* p2 = new Employee();
  Employee* p3 = new Person();
  
  p1->Name = "P1";
  p2->Name = "P2";
  p3->Name = "Babo";
  
  p1->print();
  p2->print();
  p3->print();

  return 0;
}