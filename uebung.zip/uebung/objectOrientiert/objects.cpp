#ifndef OBJECTS_CPP
#define OBJECTS_CPP

#include <iostream>
#include <string>
#include "objects.hpp"

using namespace std;


Person::Person() {
  Telefon = "000";
  Name = "???";
  Alter = 0;
}

void Person::print() {
  cout << "Name: " << Name << endl;
  cout << "Alter: " << Alter << endl;
  cout << "Tel.: " << Telefon << endl;
}

Employee::Employee() : Person() {
  Lohn = 13.5;
}

void Employee::print() {
  Person::print();
  cout << "Lohn: " << Lohn << endl;
}

Boss::Boss() : Employee() {
  Team = 12;
}

void Boss::print() {
  Employee::print();
  cout << "Team: " << Team << endl;
}

#endif

